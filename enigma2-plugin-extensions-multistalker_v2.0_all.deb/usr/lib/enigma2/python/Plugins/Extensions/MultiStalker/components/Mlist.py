from Components.MenuList import MenuList
from enigma import eListboxPythonMultiContent , gFont
from Components.MultiContent import MultiContentEntryText
from Plugins.Extensions.MultiStalker.commons.commons import isHD 

class MEntry(MenuList):
	def __init__(self, list, enableWrapAround=False):
		MenuList.__init__(self, list, enableWrapAround, eListboxPythonMultiContent)
		if isHD():
			self.l.setFont(0, gFont('Rg', 20))
			self.l.setItemHeight(35)
		else:
			self.l.setFont(0, gFont('Rg', 35))
			self.l.setItemHeight(70)

def mainEntryComponent(entry):
	res = [(entry)]
	if isHD():
		res.append(MultiContentEntryText(pos=(10, 5), size=(700, 30), font=0, text=str(entry)))
	else:
		res.append(MultiContentEntryText(pos=(10, 14), size=(700, 45), font=0, text=str(entry)))
	return res